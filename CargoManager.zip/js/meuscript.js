// JavaScript Document

$(document).ready(function() {	
	
	$("#cpfid").change(function() {
		validaCPF($(this).val());
	});
	
	$("#cnh").change(function() {
		validaCNH($(this).val());
	});
	
     $("#bday").datepicker({
		showOn: "button",
		buttonImage: "img/calen.png",
		buttonImageOnly: true		
	});
	

	
	$("#cpfid").keypress(function() {
       	$("#cpfid").mask('000.000.000-00', {reverse: true});
	});
	
	$(document).ready(function() {
              $('.menuIndex a').hover(function() {
                $(this).stop().animate({
                   opacity: 1
                 }, 200);
                    }, function() {
               $(this).stop().animate({
                opacity: 0.3
                 }, 200);
              });
            });
	
});


function validaCNH(cnh) {
	  var ret,
	  firstChar = cnh.charAt(0);
	
	  if (cnh.replace(/[^\d]/g, '').length === 11 && firstChar.repeat(11) !== cnh) {
	
		var dsc = 0;
	
		for (var i = 0, j = 9, v = 0; i < 9; ++i, --j) {
		  v += +(cnh.charAt(i) * j);
		}
	
		var vl1 = v % 11;
		if (vl1 >= 10) {
		  vl1 = 0;
		  dsc = 2;
		}
	
		for (i = 0, j = 1, v = 0; i < 9; ++i, ++j) {
		  v += +(cnh.charAt(i) * j);
		}
	
		var x = v % 11,
		  vl2 = (x >= 10) ? 0 : x - dsc;
	
		ret = '' + vl1 + vl2 === cnh.substr(-2);
	
	  }
	
	  if (ret !== true) return alert("CNH inválida");
	
	  return true;
	
}


function validaCPF(cpf) {
        cpf = cpf.replace('.','');
        cpf = cpf.replace('.','');
        cpf = cpf.replace('-','');
         
        erro = new String;
        if (cpf.length < 11) erro += "Sao necessarios 11 digitos para verificacao do CPF! \n\n"; 
        var nonNumbers = /\D/;
        if (nonNumbers.test(cpf)) erro += "A verificacao de CPF suporta apenas numeros! \n\n";  
        if (cpf == "00000000000" || cpf == "11111111111" || cpf == "22222222222" || cpf == "33333333333" || cpf == "44444444444" || cpf == "55555555555" || cpf == "66666666666" || cpf == "77777777777" || cpf == "88888888888" || cpf == "99999999999"){
              erro += "Numero de CPF invalido!"
        }
        var a = [];
        var b = new Number;
        var c = 11;
        for (i=0; i<11; i++){
            a[i] = cpf.charAt(i);
            if (i <  9) b += (a[i] *  --c);
        }
        if ((x = b % 11) < 2) { a[9] = 0 } else { a[9] = 11-x }
        b = 0;
        c = 11;
        for (y=0; y<10; y++) b += (a[y] *  c--); 
        if ((x = b % 11) < 2) { a[10] = 0; } else { a[10] = 11-x; }
        status = a[9] + ""+ a[10]
        if ((cpf.charAt(9) != a[9]) || (cpf.charAt(10) != a[10])){
            erro +="Digito verificador com problema!";
        }
        if (erro.length > 0){
            alert(erro);
        }
        return true;
}