
O Cargo Manager



Extrair o arquivo CargoManager.zip
------------------------

Clique na p�gina index.html
-----------------------

Navegue no sistema como preferir
--------------------------------